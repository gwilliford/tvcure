library(testthat)
library(spduration)

test_check("spduration")
